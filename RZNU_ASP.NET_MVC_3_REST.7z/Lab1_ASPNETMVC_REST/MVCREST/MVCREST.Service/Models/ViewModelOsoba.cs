﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCREST.Service.Models
{
    public class ViewModelOsoba
    {
        public string Ime { get; set; }
        public string Prezime { get; set; }
    }
}